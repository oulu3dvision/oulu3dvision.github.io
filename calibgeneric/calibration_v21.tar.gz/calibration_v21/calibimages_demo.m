function calibimages_demo
% CALIBIMAGES  The main routine for manual preprocessing of
% calibration images. If a circular image lens is used the ellipse
% bounding the image field is also located. CALIBIMAGES
% contains two subroutines, PROCESSIMAGES and FINDELLIPSE.  
% 
% See also CALIBCONFIG, PROCESSIMAGES, FINDELLIPSE
%

% Copyright (C) 2004-2005 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.


%configname=input('Give the name of your configuration (same as in file calibconfig.m): ','s');

disp('Give the name of your configuration (same as in file calibconfig.m): ');
file='configname.mat';
load(file,'configname');

sys=calibconfig(configname);

%imagenames=preprocessimgs(sys);
imagenames=processimages_demo(sys);

if strcmp(sys.circularimage,'yes')
  findellipse_demo(imagenames);
end