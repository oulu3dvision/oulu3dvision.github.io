function [pr,mu,sigma,iter]=emgmm1d(x,pr,mu,sigma,N)
% EMGMM1D EM-algorithm for one dimensional gaussian mixture models
%

% Copyright (C) 2005 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

%display('emgmm1d');
TOL=0.01; 
varTol=0.001;
MAX_ITER=100; 
 

if N==1
  pr=1;
  mu=mean(x);
  sigma=std(x);
  iter=1;
else
  X=x(:,ones(1,N)); var=sigma.^2; iter=0; NOT_CONVERGED=1;
  mu=mu(:)'; var=var(:)'; pr=pr(:)';
  while NOT_CONVERGED & iter <  MAX_ITER
    iter=iter+1;
    po=post(x,pr,mu,sqrt(var));
    if sum(po)==0
      po
    end    
    muNew=sum(po.*X)./sum(po); MuNew=muNew(ones(length(x),1),:);
    if mu(1)==0
      muNew(1)=0;
    end    
    varNew=sum(po.*(X-MuNew).^2)./sum(po); 
    prNew=mean(po); 
    if varNew > varTol;
      NOT_CONVERGED=(norm(prNew-pr)+norm(varNew-var)+norm(muNew-mu)>TOL);
    end
    pr=prNew;
    var=varNew; 
    mu=muNew;    
  end
  sigma=sqrt(var);
  if iter==MAX_ITER
    disp('Warning, EM-algorithm did not converge');
  end
end

function postprobs=post(x,pr,mu,sigma)

pxpercls=zeros(length(x),length(pr));
for idx=1:length(pr);
  pxpercls(:,idx)=pr(idx)*1/(sigma(idx))*exp(-0.5/((sigma(idx))^2)*(x(:)-mu(idx)).^2);
end
tot=sum(pxpercls,2);
tot=tot(:,ones(1,length(pr)));
postprobs=pxpercls./tot;
