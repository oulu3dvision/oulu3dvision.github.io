function x=generic2sphere(m,p,thetamax)


[theta,phi]=backprojectgeneric(m,p,thetamax);

x=[cos(phi).*sin(theta) sin(phi).*sin(theta) cos(theta)];
