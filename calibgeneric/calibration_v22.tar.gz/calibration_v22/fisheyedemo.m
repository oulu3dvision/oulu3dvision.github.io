function fisheyedemo

calibimages_demo
disp('Calibration images processed.');
disp('Calibration next');
pause(3);
calibrate_demo

