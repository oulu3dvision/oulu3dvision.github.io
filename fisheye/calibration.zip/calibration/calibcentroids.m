function calibcentroids
% CALIBCENTROIDS finds the circular control points and their
% centroids from the calibration images. The files saved by
% CALIBIMAGES are needed as input. The options must be set in
% CALIBCONFIG. The centroid positions in each image are saved into
% separate files. 
%
% See also CALIBCONFIG, CALIBIMAGES
%

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.


configname=input('Give the name of your configuration (same as in file calibconfig.m): ','s');

sys=calibconfig(configname);

controlpoints(sys);
