function d=projerrbasiccircular(par,ms,xs,A,B,W)
% d=projerrbasiccircular(par,ms,xs,A,B,W)
% 
% See also MINIMISEPROJERRS

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

N=length(ms);
p=par(1:6);
mu=p(3); mv=p(4); u0=p(5); v0=p(6);
lp=p(1:2); lp(19)=0;

d=[];
Ri=zeros(3,3);

for j=1:N
  count=7+(j-1)*6;
  
  rotvect=par(count:count+2);
  tj=par(count+3:count+5);
  w=rotvect(1);
  n=[sin(rotvect(2))*cos(rotvect(3)) sin(rotvect(2))*sin(rotvect(3)) ...
     cos(rotvect(2))]';
  Nx=[0 -n(3) n(2); n(3) 0 -n(1); -n(2) n(1) 0];
  Rj=n*n'+cos(w)*(eye(3)-n*n')+sin(w)*Nx;

  m=ms{j}; x=xs{j};
  M=size(m,1);
  
  for i=1:M
    X=[x(i,1) x(i,2)];
    [xi,yi]=compcentroidcircle(A,B,W,Rj,tj,X,lp);
    ui=mu*xi+u0;
    vi=mv*yi+v0;
    d=[d; m(i,1)-ui; m(i,2)-vi];
  end

end
