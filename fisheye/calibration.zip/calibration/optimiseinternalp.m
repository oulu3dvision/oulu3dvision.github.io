function p=optimiseinternalp(pinit,ms,xs,thetamax)
% p=optimiseinternalp(pinit,ms,xs,thetamax)
%
% OPTIMISEINTERNALP optimises the internal camera parameters by minimising
% the norm of the error vector given by COSTFUNH

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

options=optimset('LargeScale','off','Display','iter','MaxFunEvals',100000,'TolFun',10^(-4),'TolX',10^(-4));

p=lsqnonlin('costfunH',pinit,[],[],options,ms,xs,thetamax);
