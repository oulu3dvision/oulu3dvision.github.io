function ds=costfunH(p,ms,xs,thetamax)
% ds=costfunH(p,ms,xs,thetamax)
% 
% COSTFUNH is the cost function that is minimised with respect 
% to p

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

N=length(ms);
ds=[];

for i=1:N
  xph=generic2pinhole(ms{i},p,thetamax);
  H=homdltnorm([xs{i} xph]);
  dsi=hom1imgerr(H,xph,xs{i});
  ds=[ds; dsi];
end
