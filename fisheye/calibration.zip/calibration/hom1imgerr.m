function dvect=hom1imgerr(H,m1,m0)
%
% H = 3*3-matrix
% m1 = n*2-matrix
% m0 = n*2-matrix
%
% dvect = n*1-matrix

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

n=size(m0,1);

x0=[m0'; ones(1,n)];
Hx0=H*x0;
Hm0=Hx0(1:2,:)./(ones(2,1)*Hx0(3,:));
diffs=m1'-Hm0;
dvect=sqrt(sum(diffs.^2))';