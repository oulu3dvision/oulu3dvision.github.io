function d=homerroneimg(H,m)
% d=homerroneimg(H,m)
%
% HOMERRONEIMG is the cost function for UPDATEHOMOGRAPHIES
%

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

n=size(m,1);
coordexact=[m(:,1)'; m(:,2)'; ones(1,n)];
mH=H*coordexact;
mH=mH(1:2,:)./(ones(2,1)*mH(3,:));
d=[m(:,3)'; m(:,4)']-mH;
d=d(:);