function names=preprocessimgs(sys)
% names=calibimages(prefix,suffix,numlen,indexes,minidx,maxidx)
%
% CALIBIMAGES is the interactive routine that lets the user mark
% a polygon in each calibration image. The control points will be
% searched inside the convex hull of the polygon. The convex hulls
% are saved into files which serve as inputs for the routine
% CONTROLPOINTS. CALIBIMAGES returns the names of the calibration
% image files.
% 
% See also CALIBDATA.

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

fprintf(1,'Locate the calibration plane from the calibration images.\n\n Use left mouse button to click the vertices of a convex polygon that encloses the calibration pattern. Indicate the last vertex by the right button.\n Then define a right handed cartesian coordinate system in the calibration plane so that when x and y axis are in the plane the z axis points away from the camera.\n\n');

[idxs,names, datafnames]=makefilenames(sys);
  
N=length(idxs);
i=1;

while i<N+1
  fprintf(1,' Image %d in progress\n',idxs(i));

  img=imread(names(i,:));
  if length(size(img))>2
    img=rgb2gray(img);
  end
  
  [cartcoord,bimg,winr,gridsize]=calibboard(img);
  
  ip=input('  Satisfied? (n=no, other=yes): ','s');
  if isempty(ip) 
    save(datafnames(i,:),'cartcoord','bimg','winr','gridsize'); 
    i=i+1;
  elseif strcmp(ip,'n')
  else
    save(datafnames(i,:),'cartcoord','bimg','winr','gridsize'); 
    i=i+1;
  end
  close;

end
