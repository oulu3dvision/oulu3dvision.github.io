function H=homdltnorm(m)
% H=homdltnorm(m)
%
% HOMDLTNORM, homography estimation with linear algorithm 
% with data normalization
%
% INPUT:
%  m = [m1x m1y m2x m2y], n*4-matrix for matched points
%
% OUTPUT:
%  H = homography, 3*3-matrix

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

n=size(m,1);

m1=m(:,1:2);
c1=sum(m1)/n;
m1=m1-ones(n,1)*c1;
d1=sum(sqrt(sum(m1.^2,2)))/n;
s1=sqrt(2)/d1;
m1=s1*m1;
T1=[s1 0 s1*(-c1(1)); 0 s1 s1*(-c1(2)); 0 0 1];

m2=m(:,3:4);
c2=sum(m2)/n;
m2=m2-ones(n,1)*c2;
d2=sum(sqrt(sum(m2.^2,2)))/n;
s2=sqrt(2)/d2;
m2=s2*m2;
T2=[s2 0 s2*(-c2(1)); 0 s2 s2*(-c2(2)); 0 0 1];


H=homdlt([m1 m2]);
H=inv(T2)*H*T1;


