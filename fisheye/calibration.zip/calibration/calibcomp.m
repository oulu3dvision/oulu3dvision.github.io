function [p,Rs,ts]=calibcomp(ms,xs,pinit)
% [p,Rs,ts]=calibcomp(ms,xs)
%
% CALIBCOMP computes the optimal camera parameters. Without any
% input the calibration data is read from the files supplied by
% CALIBDATA. The camera model is given by CALIBCONFIG. 
% 
% optional input:
%   ms = the measured control point positions in each image, 
%        cell array of matrices containing two columns
%   xs = the control point positions in the calibration plane,
%        cell array of matrices containing two columns
%
% output:
%   p = the internal camera parameters, whose number depends on the
%       camera model (6, 9 or 23)
%   Rs = cell array, Rs{j} is the rotation matrix for view j
%   ts = cell array, ts{j} is the translation vector for view j
%
% See also CALIBCONFIG, CALIBDATA
%

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

configname=input('Give the name of your configuration (the name given in file calibconfig.m): ','s');
sys=calibconfig(configname);

if nargin<2 | isempty(xs) | isempty(ms)
  [ms,xs]=readdata(sys);
end
if nargin<3
  pinit=[];
end

if isempty(pinit)
  [pinit,thetamax]=initialiseinternalp(sys);
else
  thetamax=sys.viewfield/2*pi/180;
end
pinit=pinit

p0=optimiseinternalp(pinit,ms,xs,thetamax);

[Hs,err]=updatehomographies(p0,ms,xs,thetamax);
err=err

if strcmp(sys.model,'perspective')
  K=initialiseperspective(Hs)
  p0=updateinternalp(p0,K);
else
  K=eye(3);
end

[Rs0,ts0]=initialiseexternalp(Hs,K);
save p0 p0
save Rs0 Rs0
save ts0 ts0

p0=p0
[err,meanerr]=projerrs(ms,xs,p0,Rs0,ts0,sys.blobradius);
disp('Mean distance between measured and modelled centroids before nonlinear minimization')
fprintf(1,' %.4f pixels\n',meanerr);


% first just the basic model  
[p,Rs,ts]=minimiseprojerrs(ms,xs,p0,Rs0,ts0,'basic',0);
p=p
% if the initial guess is bad the general radially symmetric
% projection may give negative values for r and we need the
% following correction
if p(1)<0 | (p(1)==0 & p(2)<0)
  disp('In calibcomp: Radius must be positive');
  p(1)=-p(1); p(2)=-p(2);
  S=[-1 0 0; 0 -1 0; 0 0 1];
  for i=1:length(Rs)
    R=Rs{i};
    Rs{i}=S*Rs{i};
    ts{i}=S*ts{i};
  end
end

% if a more complex model is assumed or the control points are circular
if ~strcmp(sys.model,'basic') | sys.blobradius~=0
  [err,meanerr]=projerrs(ms,xs,p,Rs,ts,sys.blobradius);
  disp('Mean distance between measured and modelled centroids before fitting the full model')
  fprintf(1,' %.4f pixels\n',meanerr);
  [p,Rs,ts]=minimiseprojerrs(ms,xs,p,Rs,ts,sys.model,sys.blobradius);
end

save p p
save Rs Rs
save ts ts

[err,meanerr,mederr,su,sv]=projerrs(ms,xs,p,Rs,ts,sys.blobradius);

disp('Mean distance between measured and modelled centroids:')
fprintf(1,' %.4f pixels\n',meanerr);

disp('Standard deviation of the residuals:');
fprintf(1,'sigma_u: %.4f pixels\n',su);
fprintf(1,'sigma_v: %.4f pixels\n',sv);

[maxd,meand]=testbackproject(p,thetamax);

disp('The backward model error:');
fprintf(1,'maximum reprojection error: %e pixels\n',maxd);
fprintf(1,'mean reprojection error: %e pixels\n',meand);
