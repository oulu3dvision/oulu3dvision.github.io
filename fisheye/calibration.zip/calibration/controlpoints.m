function controlpoints(sys)
% CONTROLPOINTS is the routine that thresholds the calibration
% images and computes the control point centroids. This is a
% subroutine for CALIBDATA.
%
% 

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

blobcolor=sys.blobcolor;
grayscalew=sys.grayscalew;

[idxs,names, datafnames, cfnames]=makefilenames(sys);

counter=1;
disp('Searching control points ...');
for i=1:length(idxs)
  fprintf(' Image %d in progress\n',idxs(i));
  load(datafnames(i,:));
  nx=gridsize(1);
  ny=gridsize(2);

  img=imread(names(i,:));
  if length(size(img))>2
    img=rgb2gray(img);
  end
 
  blobs=findblobs(img, bimg, winr,blobcolor);   
  [ydim,xdim]=size(img);
  %figure; imshow(blobs);
  [SUCCESS, cmat, blobs]=arrangeblobs(blobs, gridsize,cartcoord);
  if ~SUCCESS
    fprintf('   In controlpoints: Can not find all blobs from image %d.\n',idxs(i));
    %figure; imshow(blobs);
    %keyboard
    cm{counter}=[];
    counter=counter+1;
    continue;
  end                                                         

  if strcmp(grayscalew,'gray')
    cmatold=cmat;
    [cmat,blobs]=blobsgrayscale(img,blobs,cmat,blobcolor);
    %figure; imshow(blobs);
    xdiff=cmat(:,:,1)-cmatold(:,:,1);
    ydiff=cmat(:,:,2)-cmatold(:,:,2);
    totdiff=sqrt(xdiff.^2+ydiff.^2);
    mdiff=mean(mean(totdiff));
  end
  
  save(cfnames(counter,:),'cmat');
  fighandle=blobvis(img,blobs,cmat);
  counter=counter+1;
  
  disp('  Press any key to proceed to the next image');
  pause
  
  close(fighandle);
  
end
