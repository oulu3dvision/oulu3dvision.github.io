function K=initialiseperspective(Hs)

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

N=length(Hs);
A=[];
for i=1:N
  H=Hs{i};
  
  h=H(:);
  a1=[h(1)*h(4) h(1)*h(6)+h(3)*h(4) h(2)*h(5)...
     h(2)*h(6)+h(3)*h(5) h(3)*h(6)];
  a2=[h(1)^2 2*h(1)*h(3) h(2)^2 2*h(2)*h(3) h(3)^2]-...
     [h(4)^2 2*h(4)*h(6) h(5)^2 2*h(5)*h(6) h(6)^2];
  A=[A; a1; a2];  
end

if N>1
  for i=1:5
    na(i)=norm(A(:,i));
    A(:,i)=A(:,i)/na(i);
  end
  [U,S,V]=svd(A);
  b=V(:,end)./na(:);
  t=sqrt(b(3)/b(1));
  x0=-b(2)/b(1); y0=-b(4)/b(3);
  f=sqrt((b(1)*b(3)*b(5)-b(3)*b(2)^2-b(1)*b(4)^2)/(b(1)*b(3)^2));
  K=[t*f 0 x0; 0 f y0; 0 0 1];
else
  disp('In initialiseperspective: With a pinhole camera you need more than a one view of the calibration plane!');
  K=[];
end

