function [Hs,err]=updatehomographies(p,ms,xs,thetamax)
% [Hs,err,K]=updatehomographies(p,ms,xs,thetamax)
%
% UPDATEHOMOGRAPHIES computes the homographies between the
% calibration points and their images that are transformed to
% follow the perspective projection.
%
% input:
%   p = [k1 k2 mu mv u0 v0], the internal camera parameters
%   ms = cell array, ms{j}=[u v], the image coordinates
%   xs = cell array, xs{j}=[X Y], coordinates in the calibration plane
%   thetamax = the maximum value of theta angle
%
% output:
%   Hs = cell array, Hs{j} is the homography for view j
%   err = the mean residuals, E[ ||x'-Hx|| ], for each view 

%   K = upper triangular matrix so that H=K[r1 r2 t],
%       computed only when length(ms)>1 (i.e. more than one view),
%       otherwise empty

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

N=length(ms);
A=[];
for i=1:N
  xph=generic2pinhole(ms{i},p,thetamax);
  H0=homdltnorm([xs{i} xph]);
  options=optimset('LargeScale','off','LevenbergMarquardt','on', 'Display','iter','MaxFunEvals',100000);
  [H,resnorm,res]=lsqnonlin('homerroneimg',H0,[],[],options,[xs{i} xph]);
  err(i)=mean(abs(res));
  Hs{i}=H;
end

