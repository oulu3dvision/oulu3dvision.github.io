function calibimages
% CALIBIMAGES  The main routine for manual preprocessing of
% calibration images. If a circular image lens is used the ellipse
% bounding the image field is also located. CALIBIMAGES
% contains two subroutines, PREPROCESSIMGS and FINDELLIPSE.  
% 
% See also CALIBCONFIG, PREPROCESSIMGS, FINDELLIPSE
%

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.


configname=input('Give the name of your configuration (same as in file calibconfig.m): ','s');

sys=calibconfig(configname);

imagenames=preprocessimgs(sys);

if strcmp(sys.circularimage,'yes')
  findellipse(imagenames);
end