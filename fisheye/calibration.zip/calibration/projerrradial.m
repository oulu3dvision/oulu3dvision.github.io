function d=projerrradial(par,ms,xs)
% d=projerrradial(par,ms,xs) 
%
% See also MINIMISEPROJERRS
%

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

N=length(ms);

p=par(1:9); p(23)=0;
d=[];

for i=1:N
  count=10+(i-1)*6;
  rotvect=par(count:count+2);
  ti=par(count+3:count+5);
  w=rotvect(1);
  n=[sin(rotvect(2))*cos(rotvect(3)) sin(rotvect(2))*sin(rotvect(3)) ...
     cos(rotvect(2))]';
  Nx=[0 -n(3) n(2); n(3) 0 -n(1); -n(2) n(1) 0];
  Ri=n*n'+cos(w)*(eye(3)-n*n')+sin(w)*Nx;

  M=size(ms{i},1);
  mh=genericprojextended([xs{i} zeros(M,1)],p,Ri,ti);
  m=ms{i};
  err=m'-mh';
  d=[d; err(:)];
end
