function xph=generic2pinhole(m,p,thetamax)
% xph=generic2pinhole(m,p,thetamax)
%
% GENERIC2PINHOLE back-projects image points and then re-projects
% them using the pinhole model (with f=1)
%
% input:
%   m = [u v] the pixel coordinates
%   p = [k1 k2 mu mv u0 v0] the camera parameters
%   thetamax = maximum value for the theta angle 
%
% output:
%   xph = [x y] the pinhole coordinates
%

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

[theta,phi]=backprojectgeneric(m,p,thetamax);

% normalised pinhole coordinates with f=1 
rph=tan(theta);
x=rph.*cos(phi); y=rph.*sin(phi);

xph=[x y];
  
