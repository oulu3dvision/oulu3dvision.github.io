function H=homdlt(m)
% H=homdlt(m)
%
% HOMDLT, homography estimation with linear algorithm 
% without data normalization
%
% INPUT:
%  m = [m1x m1y m2x m2y], n*4-matrix for matched points
%
% OUTPUT:
%  H = homography, 3*3-matrix

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

A=zeros(3*size(m,1),9);

for idx=1:size(m,1)
  xL=[m(idx,1:2)';1];
  xR=[m(idx,3:4)';1];
  A(3*idx-2:3*idx,:)=[0 0 0 -xL' xR(2)*xL';...
		      xL' 0 0 0 -xR(1)*xL';...
		      -xR(2)*xL' xR(1)*xL' 0 0 0];
end

[U,S,V]=svd(A);
h=V(:,size(V,2));
H=zeros(3); H(:)=h; H=H';

