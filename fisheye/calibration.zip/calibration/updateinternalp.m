function p=updateinternalp(p0,K)

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

if isempty(K)
  p=p0;
  return;
end

K=1/K(3,3)*K;

p=[p0(1) p0(2) K(1,1)/p0(1) K(2,2)/p0(1)  K(1,3) K(2,3)]';