function [pr,mu,sigma,iter]=em(x,arg1,arg2,arg3,N)
% [pr,mu,sigma,iter]=em(x,arg1,arg2,arg3,N)
%
% EM returns parameters for 1-D gaussian mixture model
%   EM(X,N)
%   EM(X,PR0,MU0,SIGMA0)
%

% Copyright (C) 2004 Sami Brandt and Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.


if nargin < 4
  N=arg1;
  tau=arg2;
else
  pr=arg1;
  mu=arg2;
  sigma=arg3;
  N=length(pr);
  if length(mu)<length(pr);
    mu=[0;mu(:)];
  end  
end

TOL=0.01; 
varTol=0.001;
MAX_ITER=1000; 

%Initialization
  a=min(x);
  b=max(x);

if nargin < 4 & N~=1
  pr=[1/2;1/(2*(N-1))*ones(N-1,1)]; %Guess for priors
  mu=[0;(a+(b-a)/(2*(N-1)))+(b-a)/(N-1)*(0:N-2)']; %Guess for means    
  sigma=tau*(b-a)*[1/20;1/(N-1)*ones(N-1,1)]; %Guess for the deviations
end
 
%Computation      
if N==1
  pr=1;
  mu=mean(x);
  sigma=std(x);
  iter=1;
else
  X=x(:,ones(1,N)); var=sigma.^2; iter=0; NOT_CONVERGED=1;
  mu=mu(:)'; var=var(:)'; pr=pr(:)';
  while NOT_CONVERGED & iter <  MAX_ITER
    iter=iter+1;
    po=post(x,pr,mu,sqrt(var));
%    po
%    if sum(isnan(var))  
%      po
%      var
%    end 
  if sum(po)==0
    po
  end
  
    muNew=sum(po.*X)./sum(po); MuNew=muNew(ones(length(x),1),:);%Update means 
    if mu(1)==0
      muNew(1)=0;
    end    
    varNew=sum(po.*(X-MuNew).^2)./sum(po); %Update variances
    prNew=mean(po); %Update priors
    if varNew > varTol;
      NOT_CONVERGED=(norm(prNew-pr)+norm(varNew-var)+norm(muNew-mu)>TOL);
    else 
%      disp('Perturbing singularity points');
      I=find(varNew<varTol | sum(isnan(varNew)));
      varNew(I)=normrnd(zeros(size(I)),(b-a)/3).^2;
%varNew(I)=ones(size(I))*((1/3)*(b-a)).^2;
%      varNew(I)=varTol;
      %varNew(I)=(b-a)/3+normrnd(zeros(size(I)),(b-a)/6).^2;
      %muNew(I)=a+(b-a)/2+normrnd(zeros(size(I)),(b-a)/3).^2;
      %muNew(I)=x(ceil(length(x)*rand(1)));
    end
    pr=prNew;
    var=varNew; 
    mu=muNew;    
  end
  sigma=sqrt(var);
  if iter==MAX_ITER
    disp('Warning, the method did not converge');
  end
end

function pCGivenX=post(x,pr,mu,sigma)

PrPxGivenC=zeros(length(x),length(pr));
for idx=1:length(pr);
  PrPxGivenC(:,idx)=pr(idx)*normpdf(x,mu(idx),sigma(idx));
end
tot=sum(PrPxGivenC,2);
tot=tot(:,ones(1,length(pr)));
pCGivenX=PrPxGivenC./tot;
