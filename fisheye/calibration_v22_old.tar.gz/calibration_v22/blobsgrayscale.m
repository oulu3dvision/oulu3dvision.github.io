function [cmatnew,blobsext]=blobsgrayscale(img,blobs,cmat,blobcolor)
% BLOBSGRAYSCALE computes the blob centroids by weighting the
% pixels with their grayscale values
%

% Copyright (C) 2004 Juho Kannala
%
% This software is distributed under the GNU General Public
% Licence (version 2 or later); please refer to the file
% Licence.txt, included with the software, for details.

se=strel('disk',1,0);
nx=size(cmat,2);
ny=size(cmat,1);
dx=size(img,2);
dy=size(img,1);
blobsext=zeros(dy,dx);

for j=1:ny
  for i=1:nx
    lb=bwlabel(blobs);
    num=lb(ceil(cmat(j,i,2)),ceil(cmat(j,i,1)));
    blobji=(lb==num);
    blobjiext=imdilate(blobji,se);
    bjiind=find(blobjiext);
    blobsext=(blobsext | blobjiext);
    if strcmp(blobcolor,'white')
      minval=min(double(img(bjiind)));
      blobjiimg=double(blobjiext).*(double(img)-minval);
    else
      maxval=max(double(img(bjiind)));
      blobjiimg=double(blobjiext).*(maxval-double(img));
    end
    [X,Y]=meshgrid(1:dx,1:dy);
    cmatnew(j,i,1)=sum(sum(X.*blobjiimg))/sum(sum(blobjiimg));
    cmatnew(j,i,2)=sum(sum(Y.*blobjiimg))/sum(sum(blobjiimg));
  end
end


