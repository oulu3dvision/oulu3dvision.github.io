function d=homangleerr(H,x,xp)

M=size(x,1);

xn=x./(sqrt(sum(x.^2,2))*ones(1,3));
xs=(H*xp')';
xs=xs./(sqrt(sum(xs.^2,2))*ones(1,3));

for i=1:M
  d(i)=sin(acos(xn(i,:)*(xs(i,:))'));
end

d=d(:);
